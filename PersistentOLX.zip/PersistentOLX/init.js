angular.module('persistentOLXApp', ['ui.router', 'ngSanitize', 'searchBox', 'productDetails', 'sellerInformation', 'productDescription', 'productSpecifications'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/home');
        $stateProvider
            .state('home', {
                url: '/home',
                controller: 'productDetailsController'
            })
            .state('productDetails', {
                url: '/productDetails',
                templateUrl: 'templates/productDetails.html',
                controller: 'productDetailsController'
            })
            .state('productDetails.productDescription', {
                url: '/productDescription',
                templateUrl: 'templates/productDescription.html',
                controller: 'productDescriptionController'
            })
            .state('productDetails.productSpecification', {
                url: '/productSpecification',
                templateUrl: 'templates/productSpecification.html',
                controller: 'productSpecificationController'
            })
            .state('sellerInformation', {
                url: '/sellerInformation',
                templateUrl: 'templates/sellerInformation.html',
                controller: 'sellerInformationController'
            });
    });