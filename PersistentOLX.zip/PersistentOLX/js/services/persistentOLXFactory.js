angular.module('persistentOLXApp')
    .factory('persistentOLXFactory', function ($http, $q) {
        return {
            itemDetails:{},
            fetchPhonesList: function (url) {
                var deferred = $q.defer();
                $http.get('./data/' + url + '.json').success(function (data, status, headers, config) {
                    deferred.resolve(data, status, headers, config);
                }).error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config)
                });
                return deferred.promise;
            },
            fetchSearchItemDetails:function(phoneID){
                var deferred = $q.defer();
                var self = this;
                $http.get('./data/' + phoneID + '.json').success(function (data, status, headers, config) {
                    self.itemDetails = data;
                    deferred.resolve(data, status, headers, config);
                }).error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config)
                });
                return deferred.promise;
            }
        }
    });