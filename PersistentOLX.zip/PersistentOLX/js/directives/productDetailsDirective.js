angular.module('productDetails', [])
    .directive('productDetails', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/productDetailsPartials.html',
            link: function ($scope) {
                $scope.pdExpand = true;
                $scope.pdCollapse = false;
                $scope.psExpand = true;
                $scope.psCollapse = false;
                $('#productDescription').on('shown.bs.collapse', function () {
                    $scope.pdExpand = false;
                    $scope.pdCollapse = true;
                    $('#productSpecifications').collapse('hide');
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                });
                $('#productDescription').on('hidden.bs.collapse', function () {
                    $scope.pdExpand = true;
                    $scope.pdCollapse = false;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                });
                $('#productSpecifications').on('shown.bs.collapse', function () {
                    $scope.psExpand = false;
                    $scope.psCollapse = true;
                    $('#productDescription').collapse('hide');
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                });
                $('#productSpecifications').on('hidden.bs.collapse', function () {
                    $scope.psExpand = true;
                    $scope.psCollapse = false;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                });
            }
        }
    });