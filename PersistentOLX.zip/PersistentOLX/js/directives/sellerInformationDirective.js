angular.module('sellerInformation', [])
    .directive('sellerInformation', function (persistentOLXFactory, $state) {
        return {
            restrict:'E',
            templateUrl:'templates/sellerInformationPartials.html',
        }
    });