angular.module('persistentOLXApp')
    .controller('productDescriptionController', function ($scope, persistentOLXFactory) {
        var data = persistentOLXFactory.itemDetails;
        $scope.name = data.name;
        $scope.description = data.description;
        $scope.images = data.images;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });