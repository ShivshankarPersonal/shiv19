angular.module('persistentOLXApp')
    .controller('productDetailsController', function ($scope, $state, persistentOLXFactory) {
        $scope.onSellerInformation = function () {
            $state.go('sellerInformation');
        };
        $scope.onProductDetails = function () {
            $state.go('productDetails');
        };
        $scope.$on('searchItemClicked', function (event, phoneID) {
            persistentOLXFactory.fetchSearchItemDetails(phoneID).then(function (data) {
                $scope.name = data.name;
            }, function (data) {
                console.Error("Failed to Fetch Electronics Item Details" + data)
            })
        });
    });