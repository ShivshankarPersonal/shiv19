angular.module('persistentOLXApp')
    .controller('productSpecificationController', function ($scope, persistentOLXFactory) {
        var data = persistentOLXFactory.itemDetails;
        $scope.additionalFeatures = data.additionalFeatures;
        $scope.android = data.android;
        $scope.availability = data.availability;
        $scope.battery = data.battery;
        $scope.camera = data.camera;
        $scope.connectivity = data.connectivity;
        $scope.display = data.display;
        $scope.hardware = data.hardware;
        $scope.id = data.id;
        $scope.sizeAndWeight = data.sizeAndWeight;
        $scope.storage = data.storage;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });